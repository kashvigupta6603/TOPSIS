from setuptools import setup, find_packages

setup(
    name="Topsis-Kashvi-102303768",
    version="0.1",
    author="Kashvi Gupta",
    author_email="kgupta7_be23@thapar.edu",
    description="TOPSIS implementation as a Python package",
    packages=find_packages(),
    install_requires=["numpy", "pandas"],
    entry_points={
        "console_scripts": [
            "topsis=topsis_kashvi_102303768.topsis:main"
        ]
    },
)
