 TOPSIS Python Package

This package implements the TOPSIS (Technique for Order Preference by Similarity to Ideal Solution) method.

## Installation
```bash
pip install Topsis-Kashvi-102303768
Usage
topsis input.csv "1,1,1,1" "+,+,-,+"
Input Format
First column: Alternatives

Remaining columns: Criteria values

Weights and impacts must be comma separated

Output
Generates result.csv with TOPSIS score and rank

Assumptions
Input file is in CSV format

No missing values in data

First column is not used for computation

