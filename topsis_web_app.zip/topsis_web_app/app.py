from flask import Flask, render_template, request
import os
from topsis_kashvi_102303768.topsis import topsis

app = Flask(__name__)
UPLOAD_FOLDER = "uploads"
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER

os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        file = request.files["file"]
        weights = request.form["weights"]
        impacts = request.form["impacts"]
        email = request.form["email"]

        file_path = os.path.join(app.config["UPLOAD_FOLDER"], file.filename)
        file.save(file_path)

        result_file = topsis(file_path, weights, impacts)

        return "TOPSIS Result generated successfully. Result file: " + result_file

    return render_template("index.html")

if __name__ == "__main__":
    app.run(debug=True)
